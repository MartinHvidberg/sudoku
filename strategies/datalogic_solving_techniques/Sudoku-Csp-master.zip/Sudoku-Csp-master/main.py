import sudoku_table
import csp_backtrack

table=[[0, 3, 4, 0],
       [4, 0, 0, 2],
       [1, 0, 0, 3],
       [0, 2, 1, 0]]

